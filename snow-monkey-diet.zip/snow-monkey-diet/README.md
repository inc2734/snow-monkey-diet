# Snow Monkey Diet

![CI](https://github.com/inc2734/snow-monkey-diet/workflows/CI/badge.svg)

You can stop unused functions of the Snow Monkey.

## Build

```bash
$ npm install
$ composer install
```
